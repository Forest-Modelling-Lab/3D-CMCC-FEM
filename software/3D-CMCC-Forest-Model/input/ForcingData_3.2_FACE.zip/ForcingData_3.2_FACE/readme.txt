This file describes the ascii files provided in this directory:

co2_daily_DUKE.dat:           daily CO2 concentration data 
                                for the DUKE forest site (1996-2007)
co2_daily_ORNL.dat:           daily CO2 concentration data 
                                for the ORNL forest site (1998-2008)
nitrogen_deposition_DUKE.dat: yearly nitrogen deposition data 
                                for the DUKE forest site (1850-2100)
nitrogen_deposition_ORNL.dat: yearly nitrogen deposition data 
                                for the ORNL forest site (1850-2100)

file structure of co2_daily_????.dat
YEAR DAY_OF_YEAR AMBIENT_CO2 ELEVATED_CO2

units of CO2 concentration: ppm

file_structure of nitrogen_deposition_????.dat
YEAR N_DEPOSITION

units of N_DEPOSITION: kg N / ha / year
